echo before loop

for i in 1 2 3
do
	echo $i
	sleep 5
done
